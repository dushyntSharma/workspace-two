package collegecodingchallenge.CollegeCodingChallenge.exceptions;

public class ExceedingStrengthOfStudents extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExceedingStrengthOfStudents(String s) {
		super(s);
	}

}
