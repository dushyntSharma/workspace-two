package collegecodingchallenge.CollegeCodingChallenge.exceptions;

public class NoSuchCollegeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchCollegeException(String s) {
		super(s);
	}

}
