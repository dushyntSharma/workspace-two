package codingchallenge.CodingChallenge.dao;

import java.util.List;

import codingchallenge.CodingChallenge.model.Student;

public interface StudentDao {

	String addStudent(List<Student> student);

}
