package collegecodingchallenge.CollegeCodingChallenge.dao;

import java.util.List;

import collegecodingchallenge.CollegeCodingChallenge.model.Student;

public interface StudentDao {

	String addStudent(List<Student> student);

}
